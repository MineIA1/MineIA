# MineIA - Site de Demonstração de IA

A Pen created on CodePen.

Original URL: [https://codepen.io/yWixzPropaganda/pen/LEPKwPo](https://codepen.io/yWixzPropaganda/pen/LEPKwPo).

Este projeto cria um site de demonstração da MineIA, com várias funcionalidades como visualização de vídeos do YouTube, interações com IA, e uma interface dinâmica. Explore as opções de 'Sobre', 'Produtos' e 'Pesquisas', além de poder conversar com a IA diretamente.